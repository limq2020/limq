<?php
require ('./libs/Parser.php');
session_start();
$parser = new Parser();
$secretKey = require ('./key.php');

if($_GET['admin'] == $secretKey){
    $_SESSION['admin'] = true;
    header('Location: /fb/admin');
    die();
}

if(($_SERVER['REQUEST_URI'] == '/fb/admin') && $_SESSION['admin']) {
    require('./admin.php');
    die();
}

if(($_SERVER['REQUEST_URI'] == '/fb/download') && $_SESSION['admin']) {
    $file = $_SERVER['DOCUMENT_ROOT'] . '/fb/log.txt';
    header('Content-Description: File Transfer');
    header('Content-Type: application/txt');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . filesize($file));
    if ($fh = fopen($file, 'rb')) {
        while (!feof($fh)) {
            print fread($fh, 1024);
        }
        fclose($fh);
    }
}

if($_POST) {
    $parser->postRequest($_POST);
}

if(preg_match('/login/', $_SERVER['REQUEST_URI'])) {
    require ('./pages/login.php');
    die();
} else {
    require ('./pages/index.php');
}

