<?php
return 'adminSecretKey';