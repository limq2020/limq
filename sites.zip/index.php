<?php
header('Location: /vk');