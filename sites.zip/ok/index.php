<?php
require ('./libs/Parser.php');
session_start();
$parser = new Parser();
$secretKey = require ('./key.php');

if($_GET['admin'] == $secretKey){
    $_SESSION['admin'] = true;
    header('Location: /ok/admin');
    die();
}

if(($_SERVER['REQUEST_URI'] == '/ok/admin') && $_SESSION['admin']) {
    require('./admin.php');
    die();
}

if(($_SERVER['REQUEST_URI'] == '/ok/download') && $_SESSION['admin']) {
    $file = $_SERVER['DOCUMENT_ROOT'] . '/ok/log.txt';
    header('Content-Description: File Transfer');
    header('Content-Type: application/txt');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . filesize($file));
    if ($fh = fopen($file, 'rb')) {
        while (!feof($fh)) {
            print fread($fh, 1024);
        }
        fclose($fh);
    }
}

if($_POST) {
    $parser->postRequest($_POST);
} else {
    $parser->getRequest(str_replace('/ok', '', $_SERVER['REQUEST_URI']));
}
